# ppt_package for Codex

이 폴더는 KOSSDA 공모전 PPT/요약문 초안 생성을 위해 필요한 최소 파일만 모은 패키지입니다.

## folders
- figures_main: PPT 본문 우선 사용 그림
- figures_optional: 필요할 때 보조로 사용할 그림
- tables_core: 슬라이드 문장과 요약문 작성에 필요한 핵심 결과표
- tables_method_check: 방법론/검토용 결과표
- summaries: 사람이 읽기 쉬운 회귀/로짓 요약 txt
- instructions: ppt_storyline.txt와 codex_prompt.txt

## Codex 사용법
1. ppt_package.zip을 Codex에 업로드합니다.
2. instructions/codex_prompt.txt의 내용을 Codex 요청창에 붙여넣습니다.
3. Codex가 생성한 slide_texts.md, ppt_insert_text_by_slide.csv, figure_caption_table.csv, summary_draft.md, references_draft.md를 확인합니다.
